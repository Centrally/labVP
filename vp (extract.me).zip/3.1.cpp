﻿

#include <iostream>
using namespace std;
int main()
{
    setlocale(LC_ALL, "rus");
    int count, day;
    count = 0;
    day = 0;
    int s;
    cout << "Введите количество итоговых километров: ";
    cin >> s;
    
    int n;
    cout << "Введите количество километров за день: ";
    cin >> n;
    if (s < 0 || n < 0) {
        cout << "Введены неверные данные." << endl;
    }
    else {
        int i;
        for (i = n; i <= s; i += n) {
            count += i;
            day++;
        }
        if (i != (s + n)) {
            count += i;
            day++;
        }
        cout << "Всего он пробежал " << count << "км, это заняло " << day << " дней." << endl;
    }
    system("pause");
    return 0;
}

