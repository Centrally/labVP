﻿#include <iostream>
using namespace std;
int main() {
	setlocale(LC_ALL, "rus");
	int num;
	cout << "Введите число из числовой последовательности (конец ввода - отрицательное число): ";
	cin >> num;
	int prev = num;
	bool flag = true;
	int count = 0;
	while (num >= 0) {
		cout << "Введите число из числовой последовательности (конец ввода - отрицательное число): ";
		cin >> num;
		if (num >= 0) {
			if (prev != num) {
				flag = false;
			}
			prev = num;
			count++;
		}
		count++;
	}
	if (count == 0) {
		cout << "Введено число, завершающее последовательность" << endl;
	}
	else if(flag == true){
		cout << "Все числа числовой последовательности одинаковы" << endl;
	}
	else {
		cout << "Числа отличаются." << endl;
	}
	system("pause");
	return 0;
}