﻿#include <iostream>
using namespace std;
int main()
{
    setlocale(LC_ALL, "rus");
    double time;
    cout << "Введите результат(конец ввода - отрицательное число или 0): ";
    cin >> time; 
    if (time <= 0) {
        cout << "Введено число, завершающее программу." << endl;
    }
    else {
        double best = time;
        cout << "Лучший результат - " << best << endl;
        while (time > 0) {
            cout << "Введите результат(конец ввода - отрицательное число или 0): ";
            cin >> time;
            if (time > 0) {
                if (time < best) {
                    best = time;
                }
                cout << "Лучший результат - " << best << endl;
            }
        }
    }
    system("pause");
    return 0;
}

