﻿#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdio>
#include <Windows.h>
using namespace std;
int main() {
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	string Name;
	string word;
	//vector<string> all;
	cout << "Введите имя файла, откуда считывать данные: ";
	cin >> Name;
	int count = 0;
	ifstream fin(Name);
	if (fin.is_open()) {
		ofstream fout("out.txt");
		if (fout.is_open()) {
			cout << "Данные успешно считаны и записаны!" << endl;
			while (!fin.eof()) {
				fin >> word;
				if (word[0] == 'к') {
					word[0] = 'К';
				}
				fout << word << " ";
			}
			fin.close();
			remove(Name.c_str());
			fout.close();

		}
		else {
			cout << "Не удалось открыть файл для записи!" << endl;
		}
	}
	else {
		cout << "Не удалось открыть файл для чтения!" << endl;
	}
	system("pause");
	return 0;
}
	

		

	
	