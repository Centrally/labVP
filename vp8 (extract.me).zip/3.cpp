﻿#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <Windows.h>
using namespace std;
int main() {
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	string Name_in, Name_out;
	string word;
	vector<string> all;
	cout << "Введите имя файла, откуда считывать данные: ";
	cin >> Name_in;
	cout << "Введите имя файлаб куда записывать данные: ";
	cin >> Name_out;
	ifstream fin(Name_in);
	char buf;
	if (fin.is_open()) {
		ofstream fout(Name_out);
		if (fout.is_open()) {
			cout << "Данные успешно считаны и записаны!" << endl;
			while (!fin.eof()) {
				getline(fin, word);
				fout << word << "!" << endl;			
			}
			fin.close();
			fout.close();
		}
		else {
			cout << "Не удалось открыть файл для записи!" << endl;
		}
	}
	else {
		cout << "Не удалось открыть файл для чтения!" << endl;
	}
	system("pause");
	return 0;
}