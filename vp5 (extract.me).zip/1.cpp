﻿#include <iostream>
#include <string>
#include <cctype>
#include<windows.h>
using namespace std;
int main()
{
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    string s;
    int firstE = 0, lastE = 0;
    cout << "Введите предложение: ";
    getline(cin, s);
    int m;
    cout << "Пробелы(1-учитывать, 2-игнорировать) ";
    cin >> m;
    if (m != 1 && m != 2) {
        cout << "Неверное число";
    }
    if (m == 1) {
        int n = s.size();
        for (int i = 0; i < n; i++) {
            if (s[i] == 'е' || s[i] == 'Е') {
                firstE = i + 1;
                i = n;
            }
        }
        for (int i = n - 1; i >= 0; i--) {
            if (s[i] == 'е' || s[i] == 'Е') {
                lastE = i + 1;
                i = -1;
            }
        }

        if (firstE == lastE && firstE!=0)
            cout << "В предложении всего одна буква е, её номер " << lastE << endl;
        else if (!firstE) {
            cout << "В предложении нет букв е." << endl;
        }
        else {
            cout << "Номер первой буквы е " << firstE <<
                ", номер последней буквы е " << lastE << endl;
        }
    }
    else {
        int n = s.size();
        int cf = 0, cl = 0;
        for (int i = 0; i < n; i++) {
            if (s[i] == ' ') {
                cf++;
            }
            if (s[i] == 'е' || s[i] == 'Е') {
                firstE = i + 1 - cf;
                i = n;
            }
        }
        for (int i = n - 1; i >= 0; i--) {
            if (s[i] == 'е' || s[i] == 'Е') {
                lastE = i + 1;
                i = -1;
            }
        }
        for (int i = 0; i <lastE; i++) {
            if (s[i] == ' ') {
                cl++;
            }
        }
        lastE -= cl;
        if (firstE == lastE && firstE!=0)
            cout << "В предложении всего одна буква е, её номер " << lastE << endl;
        else if (!firstE) {
            cout << "В предложении нет букв е." << endl;
        }
        else {
            cout << "Номер первой буквы е " << firstE <<
                ", номер последней буквы е " << lastE << endl;
        }
    }
    system("pause");
    return 0;
}

