﻿#include <windows.h>
#include <iostream>
#include <string>
using namespace std;
int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	string word1, word2;
	cout << "Введите первое слово: ";
	cin >> word1;
	for (int i = 0; i < word1.size(); i++) {
		if (word1[i] >= 'A' && word1[i] <= 'Z' && isupper(word1[i])) {
			word1[i] = tolower(word1[i]);
		}
		for (char j = 'А'; j <= 'Я'; j++) {
			if (word1[i] == j) {
				word1[i] = j + 32;
				j = 'Я';
			}
		}
	}
	cout << "Введите второе слово: ";
	cin >> word2;
	for (int i = 0; i < word2.size(); i++) {
		if (word2[i] >= 'A' && word2[i] <= 'Z' && isupper(word2[i])) {
			word2[i] = tolower(word2[i]);
		}
		for (char j = 'А'; j <= 'Я'; j++) {
			if (word2[i] == j) {
				word2[i] = j + 32;
				j = 'Я';
			}
		}
	}
	if ((word1[0] >= '0' && word1[0] <= '9') || (word2[0] >= '0' && word2[0] <= '9')) {
		cout << "Введены неверные данные" << endl;
		system("pause");
		return 0;
	}
	int count = 0;
	for (int i = 0; i < word1.size(); i++) {
		for (int j = 0; j < word2.size(); j++) {
			if (word1[i] == word2[j]) {
				cout << "Да ";
				count = 1;
				j = word2.size();
			}
		}
		if (count == 0) {
			cout << "Нет ";
		}
		count = 0;
	}
	system("pause");
	return 0;
}

