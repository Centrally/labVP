﻿
//#include "stdafx.h"
#include <iostream>
using namespace std;


int NOD(int p, int q) {
	while (p && q)
		if (p >= q)
			p %= q;
		else
			q %= p;

	return q | p;
}
int main()
{
	setlocale(LC_ALL, "rus");
	int a, b;
	cout << "Введите числитель дроби: ";
	cin >> a;
	cout << "Введите знаменатель дроби: ";
	cin >> b;
	if (a <= 0 || b <= 0)
	{
		cout << "Числитель и знаменатель - натуральные числа!" << endl;
	}
	else {
		int s = NOD(a, b);
		a /= s;
		b /= s;
		cout << "Общий делитель " << s << endl;
		if (b == 1) {
			cout << "В результате получилось число " << a << endl;
		}
		else {
			cout << "Новая дробь: " << endl;
			int num_of_int = 0;
			int numer = 0;
			int c, d;
			c = a; d = b;
			while (c != 0) {
				numer++; // кол-во цифр в числителе
				c /= 10;
			}
			int denumer = 0;
			while (d != 0) {
				denumer++; // кол-во цифр в знаменателе
				d /= 10;
			}
			 c = denumer;
			 d = numer;
			 c -= d;
			 c /= 2;
			 while (c > 0) {
				 cout << " ";
				 c--;
			 }
			 cout << a << endl;
			 c = numer;
			 d = denumer;
			if (denumer > numer) {
				while (denumer != 0) {
					denumer--;
					cout << "—";
				}
			}
			else {
				while (numer != 0) {
					numer--;
					cout << "—";
				}
			}
			cout << endl;

			c -= d;
			c /= 2;
			while (c > 0) {
				cout << " ";
				c--;
			}
			cout << b << endl;
			if (b < a) {
				int int_part = 0;
				while (b < a) {
					int_part++;
					a -= b;
				}
				//---------------------------------------------------------------------------------------
				cout << "После выделения целой части: " << endl;
				/*int*/ num_of_int=0;
				/*int*/ numer = 0;
			//	int c, d;
				c = a; d = b;
				while (c != 0) {
					numer++; // кол-во цифр в числителе
					c /= 10;
				}
				c = int_part;
				while (c != 0) {
					num_of_int++;  // кол-во цифр в целой части
					c/=10;
				}
				int denumer = 0;
				while (d != 0) {
					denumer++; // кол-во цифр в знаменателе
					d /= 10;
				}
				/*int*/ c = num_of_int;
				while (c != 0) {
					c--;
					cout << " ";
				}
				for (int i = (denumer-numer)/2; i >0; i--)
					cout << " ";
				 cout << a << endl << int_part;
				 if (denumer > numer) {
					 while (denumer != 0) {
						 denumer--;
						 cout << "—";
					 }
				 }
				 else {
					 while (numer != 0) {
						 numer--;
						 cout << "—";
					 }
				 }
				 cout << endl;
				 while (num_of_int != 0) {
					 num_of_int--;
					 cout << " ";
				 }
				 cout << b << endl;
				// "-" << endl << " " << b << endl
			}
		}
	}
	system("pause");
	return 0;
}


