﻿#include <iomanip>
#include <iostream>

using namespace std;

int main()
{
	setlocale(LC_ALL, "rus");
	int n;
	cout << "Введите размер массива: ";
	cin >> n;
	if (n < 2) {
		cout << "Неверный размер" << endl;
		system("pause");
		return 0;
	}
	bool flag = false;
		int count=0;
		int* arr = new int[n];
		double temp;
		for (int i = 0; i < n; i++) {
			cout << "Введите " << i+1 << " элемент массива: ";
			cin >> temp;
			if (temp == (int)temp)
				arr[i] = temp;
			else {
				cout << "Массив должен состоять из целых чисел." << endl;
				system("pause");
				return 0;
			}
		}
		for (int i = n-1; i >0; i--) {
			if (arr[i] % 2 == 0 && arr[i - 1] % 2 == 0) {
				count = i - 1;
				i = -1;
				flag = 1;
			}
		}
		if (flag) {
			for (int i = 0; i < count; i++) {
				cout << setw(4) << arr[i];
			}
		}
		else {
			cout << "Таких чисел нет." << endl;
		}
		cout << endl;
	
	system("pause");
	return 0;
}


