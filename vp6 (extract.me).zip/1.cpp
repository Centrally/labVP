﻿//#include "stdafx.h"
#include <iostream>

using namespace std;

int main()
{
	setlocale(LC_ALL, "rus");
	int n, s, k;
	cout << "Введите размер массива: ";
	cin >> n;
	if (n <= 0) {
		cout << "Неверные данные" << endl;
	}
	else {
		int* arr = new int[n];
		cout << "Введите число s: ";
		cin >> s;
		cout << "Введите число k: ";
		cin >> k;
		if (s <= 0 || s > n || k <= 0 || k > n) {
			cout << "Неверные данные." << endl;
		}
		else {
			double f;
			s -= 1; k -= 1;
			for (int i = 0; i < n; i++) {
				cout << "Введите " << i + 1 << " элемент массива: ";
				cin >> f;
				if (f != (int)f) {
					cout << "Массив состоит из целых чисел." << endl;
					system("pause");
					return 0;
				}
				arr[i] = f;
			}
			if (arr[s] > 0) {
				cout << "Элемент s массива - положительное число" << endl;
			}
			else if (arr[s] == 0) {
				cout << "Элемент s равен 0" << endl;
			}
			else {
				cout << "Элемент s - отрицательно число" << endl;
			}
			if (arr[k] % 2 == 0) {
				cout << "Элемент k - четное число" << endl;
			}
			else if (arr[k] == 0) {
				cout << "Элемент k равен 0" << endl;
			}
			else {
				cout << "Элемент k - нечетное число" << endl;
			}
			if (arr[s] > arr[k]) {
				cout << "Элемент s больше элемента k" << endl;
			}
			else if (arr[s] == arr[k]) {
				cout << "Элементы равны" << endl;
			}
			else {
				cout << "Элемент k больше элемента s" << endl;
			}
		}
	}

	system("pause");
	return 0;
}


