﻿
#include <iostream>

using namespace std;

int main()
{
	setlocale(LC_ALL, "rus");
	int n;
	cout << "Введите размер массива: ";
	cin >> n;
	if (n <= 0) {
		cout << "Неверные данные" << endl;
	}
	else {
		int* arr_P = new int[n];
		int* arr_Cost = new int[n];
		for (int i = 0; i < n; i++) {
			cout << "Введите мощность " << i+1 << " машины: ";
			cin >> arr_P[i];
		}
		for (int i = 0; i < n; i++) {
			cout << "Введите стоимость " << i+1 << " машины: ";
			cin >> arr_Cost[i];
		}
		for (int i = 0; i < n; i++) {
			if (arr_P[i] <= 80) {
				cout << "Стоимость " << i+1 << " машины: " << arr_Cost[i] << endl;
			}
		}
	}
	system("pause");
	return 0;
}


