#include <string>
#include <vector>
#include <iostream>
using namespace std;

class Body {
	string size;
	double cost;
public:
	double btakeCost() {
		return this->cost;
	}

	friend istream& operator >>(istream& in, Body& body);
	friend ostream& operator <<(ostream& out, Body& body);
};
//ostream& operator <<(ostream& out, Body& body);
ostream& operator <<(ostream& out, Body& body) {
	return out << body.size;
}

class Power_Supply {
	int capacity;         //��������
	double cost; 
	// ��������� 
public:
	double pstakeCost() {
		return this->cost;
	}
	friend istream& operator >>(istream& in, Power_Supply& ps);
	friend ostream& operator <<(ostream& out, Power_Supply& ps);
};
//ostream& operator <<(ostream& out, Power_Supply& ps);
ostream& operator <<(ostream& out, Power_Supply& ps) {
	return out << ps.capacity << " ��";
}

class memory {
	string type;
	double cost;
	double volume;
public:
	double mrtakeCost() {
		return this->cost;
	}

  friend istream& operator >>(istream& in, memory& mr);
  friend ostream& operator <<(ostream& out, memory& mr);
};

//ostream& operator <<(ostream& out, memory& mr);
ostream& operator <<(ostream& out, memory& mr) {
	return out << mr.type << " " << mr.volume << " ��";
}

class CPU {
	double frequency; //�������
	int core;
	double cost;
public:
	double cputakeCost() {
		return this->cost;
	}
	friend istream& operator >>(istream& in, CPU& cpu);
	friend bool operator > (CPU& cp1, CPU& cp2);
	friend ostream& operator <<(ostream& out, CPU& cpu);
};
//ostream& operator <<(ostream& out, CPU& cpu);
ostream& operator <<(ostream& out, CPU& cpu) {
	return out << cpu.frequency << " ���, ���-�� ����: " << cpu.core ;
}

class PC {
	Body bd;
	Power_Supply ps;
	memory mr;
	CPU cpu;
	double cost;

public:

	PC() 
	{
	}
	PC( Body bd, Power_Supply ps, memory mr, CPU cpu )
	{
		this->bd = bd;
		this->ps = ps;
		this->mr = mr;
		this->cpu = cpu;
		this->cost = bd.btakeCost() + ps.pstakeCost()+mr.mrtakeCost()+ cpu.cputakeCost();
	}

	

	friend istream& operator >>(istream& in, PC& pc);
	friend bool operator > (PC& pc1, PC& pc2);
	friend ostream& operator << (ostream& out, PC& pc);
	friend ostream& operator <<(ostream& out, PC& pc);
	/*template<typename T>*/ friend void sort(PC* pc, int n);

};
// bool operator > (CPU& cp1, CPU& cp2);
//ostream& operator << (ostream& out, PC& pc);
ostream& operator <<(ostream& out, PC& pc) {
	return out << "������: " << pc.bd << endl <<
		"���� �������: " << pc.ps << endl <<
		"���: " << pc.mr << endl <<
		"CPU: " << pc.cpu << endl <<
		"��������� " << pc.cost << endl;
}


//template<typename T>
void sort(PC* pc, int n) {
	PC pc1;
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n-i-1; j++)
			if (pc[j].cpu > pc[j+1].cpu)
			{
				pc1 = pc[j];
				pc[j] = pc[j+1];
				pc[j+1] = pc1;
			}
}

bool operator > (CPU& cp1, CPU& cp2) {
	return cp1.frequency > cp2.frequency;
}

// bool operator > (PC& pc1, PC& pc2);

bool operator > (PC& pc1, PC& pc2) {
	return pc1.cpu > pc2.cpu;
}
//istream& operator >>(istream& in, CPU& cpu);
//
//istream& operator >>(istream& in, Body& body);
//
//istream& operator >>(istream& in, Power_Supply& ps);
//
//istream& operator >>(istream& in, memory& mr);
//
//istream& operator >>(istream& in, PC& pc);

istream& operator >>(istream& in, memory& mr) {
	return in >> mr.type >> mr.volume >> mr.cost;
}

istream& operator >>(istream& in, Power_Supply& ps) {
	return in >> ps.capacity >> ps.cost;
}

std::istream& operator >>(std::istream& in, Body& body) {
	return in >> body.size >> body.cost;
}

istream& operator >>(istream& in, CPU& cpu) {
	return in >> cpu.frequency >> cpu.core >> cpu.cost;
}

istream& operator >>(istream& in, PC& pc) {
	return in >> pc.bd >> pc.ps >> pc.mr >> pc.cpu;
}