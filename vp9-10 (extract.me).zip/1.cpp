﻿#include "pc.h"

int main() {
	setlocale(LC_ALL, "rus");
	int n;
	cout << "Введите количество пк: ";
	cin >> n;
	if (n <= 0) {
		cout << "Неверные данные." << endl;
		system("pause");
		return 0;
	}
	PC* pc = new PC[n];
	Body* body = new Body[n];
	Power_Supply* ps = new Power_Supply[n];
	memory* mr = new memory[n];
	CPU* cpu = new CPU[n];
	for (int i = 0; i < n; i++) {
		cout << "Введите характеристики " << i + 1 << " корпуса(размер, стоимость через пробел): ";
		cin >> body[i];
	}
	for (int i = 0; i < n; i++) {
		cout << "Введите характеристики " << i + 1 << " блока питания(мощность, стоимость через пробел): ";
		cin >> ps[i];
	}

	for (int i = 0; i < n; i++) {
		cout << "Введите характеристики " << i + 1 << " ОЗУ(тип, объем, стоимость через пробел): ";
		cin >> mr[i];
	}
	for (int i = 0; i < n; i++) {
		cout << "Введите характеристики " << i + 1 << " процессора(частота, кол-во ядер, стоимость через пробел): ";
		cin >> cpu[i];
	}
	PC Pc;
	for (int i = 0; i < n; i++) {
		Pc={ body[i], ps[i], mr[i], cpu[i] };
		pc[i]=Pc;
	}
	sort(pc, n);

	cout << pc[n - 1];

	system("pause");
	return 0;
}