﻿
//#include "stdafx.h"
#include <string>
#include <iostream>
#include <Windows.h>
using namespace std;

struct Person {
	string Name;
	int age;
	string mil;
};
std::istream& operator >> (std::istream& cin, Person& person) {
	cout << "Введите фамилию, возраст и отношение к воинской службе (да, нет) человека через пробел: "; // да - военнообязанный, нет - нет
	return cin >> person.Name >> person.age >> person.mil;
}
bool operator> (const Person& p1, const Person& p2)
{
	return p1.age > p2.age;
}

int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	int n;
	cout << "Введите количество человек: ";
	cin >> n;
	if (n <= 0) {
		cout << "Неверные данные" << endl;
		system("pause");
		return 0;
	}
	Person* group = new Person[n];
	for (int i = 0; i < n; i++) {
		cin >> group[i];
	}
	Person temp;
	for (int i = 0; i < n-1; i++) {
		for (int j = 0; j < n - i - 1; j++) {
			if (group[j] > group[j + 1]) {
				temp = group[j];
				group[j] = group[j + 1];
				group[j + 1] = temp;
			}
		}
	}
	for (int i = 0; i < n; i++) {
		if (group[i].mil[0] == 'Д') {
			group[i].mil[0] = 'д';
		}
		else if(group[i].mil[0]=='Н') {
			group[i].mil[0] = 'н';
		}
	}
	cout << "Самый младший военнообязанный: ";
	for (int i = 0; i < n; i++) {
		if (group[i].mil[0] == 'д') {
			cout << group[i].Name << endl;
			i = 16;
		}
	}
	cout << "Самый старший военнообязанный: ";
	for (int i = n-1; i >= 0; i--) {
		if (group[i].mil[0] == 'д') {
			cout << group[i].Name << endl;
			i = -1;
		}
	}
	cout << "Самый старший невоеннообязанный: ";
	for (int i = n-1; i >= 0; i--) {
		if (group[i].mil[0] == 'н') {
			cout << group[i].Name << endl;
			i = -1;
		}
	}
	system("pause");
	return 0;
}


