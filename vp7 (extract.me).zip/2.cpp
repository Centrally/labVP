﻿
//#include "stdafx.h"
#include <math.h>
#include <iostream>
using namespace std;

int main()
{
	setlocale(LC_ALL, "rus");
	int** arr;
	int* arr1;
	int n, m;
	cout << "Введите размер массива(n, 'space', m): ";
	cin >> n >> m;
	if (n <= 0 || m <= 0) {
		cout << "Неверные данные." << endl;
	}
	else {
		arr = new int* [n];
		for (int i = 0; i < n; i++) {
			arr[i] = new int[m];
		}
		double temp;
		arr1 = new int[m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				cout << "Введите элемент " << i + 1 << " строки " << j + 1 << " столбца: ";
				cin >> temp;
				if (temp != (int)temp) {
					cout << "Массив должен состоять из целых чисел." << endl;
					system("pause");
					return 0;
				}
				else {
					arr[i][j] = temp;
				}
			}
		} 
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				cout << arr[i][j] << " ";
			}
			cout << endl;
		}
		int max = 0;
		for (int j = 0; j < m; j++) {
			for (int i = 0; i < n; i++) {
				if (abs(arr[i][j]) > abs(max)) {
					max = arr[i][j];
				}
				arr1[j] = max;
			}
			max = 0;
		}
		cout << endl << "Получившийся массив: " << endl;
		for (int i = 0; i < m; i++) {
			cout << arr1[i] << " ";
		}
		cout << endl;
	}
	system("pause");
	return 0;
}


