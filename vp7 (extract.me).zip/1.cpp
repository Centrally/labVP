﻿
//#include "stdafx.h"
#include <iostream>
using namespace std;

int main()
{
	setlocale(LC_ALL, "rus");
	int** arr;
	int st, sto;
	int n, m;
	cout << "Введите размер массива(n, 'space', m): ";
	cin >> n >> m;
	if (n <= 0 || m <= 0) {
		cout << "Неверные данные." << endl;
	}
	else {
		arr = new int* [n];
		for (int i = 0; i < n; i++) {
			arr[i] = new int[m];
		}
		double temp;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				cout << "Введите элемент " << i + 1 << " строки " << j + 1 << " столбца: ";
				cin >> temp;
				if (temp != (int)temp) {
					cout << "Массив должен состоять из целых чисел." << endl;
					system("pause");
					return 0;
				}
				else {
					arr[i][j] = temp;
				}
			}
		}
		cout << "Введите К строку массива: ";
		cin >> st;
		cout << "Введите N столбец массива: ";
		cin >> sto;
		if (st <= 0 || st > n || sto <= 0 || sto > m) {
			cout << "Неверные данные." << endl;
			system("pause");
			return 0;
		}
		st--;
		sto--;
		int i;
		for (i = 0; i < m; i++) {
			if ((arr[st][i] - 3) % 10 == 0) {
				cout << "Элемент в строке " << st + 1 << ", заканчивающийся тройкой существует, его координаты:" << endl <<
					"(" << st + 1 << "," << i + 1 << ")" << endl;
				i = m + 3;
			}
		}
		if (i == m) {
			cout << "Элемента в строке " << st + 1 << ", заканчивающегося тройкой не существует" << endl;
		}
		for (i = 0; i < n; i++) {
			if (arr[i][sto] == 0) {
				cout << "Элемент в столбце " << sto + 1 << ", равный нулю существует, его координаты:" << endl <<
					"(" << i + 1 << "," << sto + 1 << ")" << endl;
				i = n + 3;
			}
		}
		if (i == n) {
			cout << "Элемента в столбце " << sto + 1
				<< ", равного нулю не существует" << endl;
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				cout << arr[i][j] << " ";
			}
			cout << endl;
		}
	}
	system("pause");
	return 0;
}


