﻿#include <iostream>
#include <string>
#include <cctype>
#include<windows.h>
using namespace std;
int main()
{
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    string word1, word2;
    cout << "Введите первое слово: ";
    cin >> word1;
    if (word1[0]>='A' && word1[0] <='Z'&& isupper(word1[0])) {
        word1[0] = tolower(word1[0]);
    }
    for (char i = 'А'; i <= 'Я'; i++) {
        if (word1[0] == i) {
            word1[0] = i + 32;
            i = 'Я';
        }
    }
        cout << "Введите второе слово: ";
        cin >> word2;
        if ((word1[0] >= '0' && word1[0] <= '9') || (word2[0] >= '0' && word2[0] <= '9')) {
            cout << "Введено число." << endl;
            system("pause");
            return 0;
        }
        if (*word1.begin() == *(word2.end() - 1)) {
            cout << "Верно." << endl;
        }
        else
            cout << "Неверно." << endl;
    
    system("pause");
    return 0;
}
