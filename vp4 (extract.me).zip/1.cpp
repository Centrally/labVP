﻿
#include <iostream>
using namespace std;
int main()
{
	setlocale(LC_ALL, "rus");
	int x, a, n;
	int count = 0;
	cout << "Введите количество чисел: ";
	cin >> n;
	cout << "Введите число х: ";
	cin >> x;
	if (n <= 0 || x<0) {
		cout << "Введены неверные данные" << endl;
	}
	else {
		for (int i = 0; i < n; i++) {
			cout << "Введите " << i + 1 << " число: ";
			cin >> a;
			if (a < 0)
				count++;
		}
		if (count > x)
			cout << "Верно" << endl;
		else if(count <x){
			cout << "Не верно" << endl;
		}
		else {
			cout << "Количество совпадает." << endl;
		}
	}
	system("pause");
	return 0;
}

