﻿#include <iostream>
using namespace std;
int main()
{
	setlocale(LC_ALL, "rus");
	double a, maxA = 0;
	bool flag = 1;
	int sum = 0, max = 0, i, j;
	for (i = 0; i < 8 && flag; i++) {
		cout << "Введите результаты " << i + 1 << " спортсмена: ";
		for (j = 0; j < 5 && flag; j++) {
			cin >> a;
			if (a < 0) {
				flag = 0;
			}
			else {
				sum += a;
				if (maxA < a)
					maxA = a;
			}
		}
		if (sum > max) {
			max = sum;
		}
		sum = 0;
	}
	if (!flag) {
		cout << "Введены неверные данные" << endl;
	}
	else {
		cout << "Максимальная оценка в таблице - " << maxA  << ", "<< endl << 
			"Победитель набрал " << max << " баллов" << endl;
		
	}
	system("pause");
	return 0;
}
